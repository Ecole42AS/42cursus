/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minishell.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: astutz <astutz@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/25 17:17:15 by astutz            #+#    #+#             */
/*   Updated: 2023/09/06 13:58:07 by astutz           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MINISHELL_H
#define MINISHELL_H

#include <stdio.h>
#include <termios.h>
#include <unistd.h>
#include "libft/libft.h"
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stddef.h>
#include <readline/readline.h>
#include <readline/history.h>
#include <fcntl.h>
#include <signal.h>
#include <readline/readline.h>	

extern int	g_exit_code;


typedef enum
{
	UNKNOWN, // Valeur par défaut
	COMMAND,
	ARGUMENT,
	REDIRECTION,
	ENV_VAR,
	SINGLE_QUOTE_CONTENT,
	DOUBLE_QUOTE_CONTENT
} TokenType;

typedef struct s_parsing
{
	int id; // si il y a des pipes,
	int infile;
	int outfile;
	char *cmd;
	char type; //C = commande, P = program, B = builtin
	char *arg;
	struct s_parsing *next;
} t_pars;

typedef struct tokens {
    char *token;
    struct tokens *next;
} tokens;

typedef struct command_list
{
	char *command;
	
	struct command_list *next;
} command_list;

typedef struct argument_list
{
	char *argument;
	struct argument_list *next;
} argument_list;

typedef struct redirection_list
{
	char *redirection;
	struct redirection_list *next;
} redirection_list;

typedef struct env_var_list
{
	char *name;
	char *value;
	struct env_var_list *next;
} env_var_list;

typedef struct inputfile
{
	char *inputfile_content;
	struct inputfile *next;
} inputfile;

typedef struct double_inputfile
{
	char *double_inputfile_content;
	struct double_inputfile *next;
} double_inputfile;

typedef struct outputfile
{
	char *outputfile_content;
	struct outputfile *next;
} outputfile;

typedef struct double_outputfile
{
	char *double_outputfile_content;
	struct double_outputfile *next;
} double_outputfile;

typedef struct single_quote_list
{
	char *single_quote_content;
	struct single_quote_list *next;
} single_quote_list;

typedef struct double_quote_list
{
	char *double_quote_content;
	struct double_quote_list *next;
} double_quote_list;


// typedef struct s_env {
//     int alpha;
//     char *path;
//     char **var;
//     struct s_env *next;
// } t_env;

typedef struct command_line
{
	command_list		*commands;
	argument_list		*arguments;
	redirection_list	*redirections;
	env_var_list		*variables;
	single_quote_list	*single_quote_contents;
	double_quote_list	*double_quote_contents;
} command_line;

typedef struct s_token
{
	char 			*command;
	TokenType		type;
	// t_env *envi;
	env_var_list	*env;
	int				i;
	char 			*single_quote_content;
	char 			*double_quote_content;
	char 			*redirection;
	char 			*env_var_name;
	char 			*env_var_value;
	char 			*argument;
	struct 	t_token *next;
} 					t_token;

bool	is_command(const char *name);
void	get_command(t_token *token, const char *input);
void 	add_to_command_list(command_list **list, char *command);
void 	add_to_single_quote_list(single_quote_list **list, tokens *token);
void 	get_double_quote_content(t_token *new, char *input);
void 	add_to_double_quote_list(double_quote_list **list, tokens *token);
bool 	is_redirection(char c);
void 	get_redirection(t_token *token, char *input);
void 	add_to_redirection_list(redirection_list **list, t_token *token);
bool 	is_env_var(char c);
void 	get_env_var(t_token *token, char *input);
// void add_to_env_var_list(env_var_list **list, t_token *token);
void 	add_to_env_var_list(env_var_list **head, char *name, char *value);
void 	add_to_argument_list(argument_list **list, tokens *token);
void 	get_argument(t_token *token, char *input);
// void	print_linked_list(t_token *head);
void	init_termios(void);
// void 	lexer(char *input, env_var_list *env, command_line **line);
char **lexer(char *input);
// tokens *lexer(char *input);
char	*get_content_inside_single_quotes(const char *token);
void	add_to_single_quote_list(single_quote_list **list, tokens *token);
char	*get_content_inside_double_quotes(const char *input);
void	add_to_double_outputfile_list(double_outputfile **list, tokens *token);
void	add_to_double_inputfile_list(double_inputfile **list, tokens *token);
void	add_to_inputfile_list(inputfile **list, tokens *token);
void	add_to_outputfile_list(outputfile **list, tokens *token);
void	initialize_parsing(t_pars *my_pars);
void	parser(char **words, t_pars *parsing);
void	print_linked_list(t_pars *head);
void	signals_init(void (*signals_handle)(int));
void	signals_handle_input(int sig);
void	signals_handle_execution(int sig);




#endif
