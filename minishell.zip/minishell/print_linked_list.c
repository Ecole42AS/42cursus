/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_linked_list.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: astutz <astutz@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/30 13:21:04 by astutz            #+#    #+#             */
/*   Updated: 2023/09/04 20:53:23 by astutz           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

void print_linked_list(t_pars *head) {
    t_pars *current = head;

    while (current != NULL) {
        printf("id: %d\n", current->id);
        printf("infile: %d\n", current->infile);
        printf("outfile: %d\n", current->outfile);
        printf("cmd: %s\n", current->cmd);
        printf("type: %c\n", current->type);
        printf("arg: %s\n", current->arg);

        // Move to the next node
        current = current->next;
    }
}

// void print_linked_list(t_token *head) {
//     t_token *current = head; // Commence par le premier élément

//     while (current != NULL) {
//         printf("Command: %s\n", current->command);
//         printf("Type: %d\n", current->type);
//         printf("Env Var Name: %s\n", current->env_var_name);
//         printf("Env Var Value: %s\n", current->env_var_value);
//         printf("Argument: %s\n", current->argument);
//         printf("Single Quote Content: %s\n", current->single_quote_content);
//         printf("Double Quote Content: %s\n", current->double_quote_content);
//         printf("Redirection: %s\n", current->redirection);
//         printf("Index: %d\n", current->i);
//         // Affichez d'autres champs si nécessaire
        
//         current = current->next; // Passe à l'élément suivant
//         printf("\n"); // Ajoute un saut de ligne pour séparer les éléments
//     }
// }


// int main()
// {
// 	print_linked_list(head);
// }