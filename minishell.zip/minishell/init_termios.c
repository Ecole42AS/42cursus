/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   init_termios.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: astutz <astutz@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/23 13:36:45 by astutz            #+#    #+#             */
/*   Updated: 2023/09/02 11:04:35 by astutz           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */


#include "minishell.h"

/*Initialiser les paramètres du terminal en désactivant l'écho des caractères de contrôle.*/
void	init_termios(void)
{
	struct termios	termios;

	if (tcgetattr(STDIN_FILENO, &termios) == -1)
		exit(EXIT_FAILURE);

	termios.c_lflag &= ~ECHOCTL;

	if (tcsetattr(STDIN_FILENO, TCSANOW, &termios) == -1)
		exit(EXIT_FAILURE);
}
