/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   env.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: astutz <astutz@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/28 17:02:03 by astutz            #+#    #+#             */
/*   Updated: 2023/09/01 16:55:13 by astutz           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"

bool is_env_var(char c)
{
	// Vérifiez si le caractère c est le début d'une variable d'environnement ("$")
	return (c == '$');
}

void get_env_var(t_token *token, char *input)
{
	int start = token->i + 1; // Début de la variable d'environnement
	int end = start;		  // Fin de la variable d'environnement

	while (input[end] && ft_isalnum(input[end]))
	{
		end++; // Avance jusqu'au prochain caractère non alphanumérique
	}

	// Allouer de la mémoire pour stocker le nom de la variable d'environnement
	token->env_var_name = malloc(sizeof(char) * (end - start + 1));
	if (!token->env_var_name)
	{
		perror("Issue malloc get_env_var");
		exit(EXIT_FAILURE);
	}

	// Copier le nom de la variable d'environnement dans la nouvelle chaîne
	int j = 0;
	for (int i = start; i < end; i++)
	{
		token->env_var_name[j] = input[i];
		j++;
	}
	token->env_var_name[j] = '\0'; // Terminer la chaîne

	token->i = end; // Mettez à jour l'index pour pointer au caractère après la variable d'environnement
}

void add_to_env_var_list(env_var_list **head, char *name, char *value) {
    env_var_list *new_node = (env_var_list *)malloc(sizeof(env_var_list));
    if (new_node) {
        new_node->name = strdup(name);
        new_node->value = strdup(value);
        new_node->next = *head;
        *head = new_node;
    }
}

env_var_list *parse_environment(char **environ) {
    env_var_list *env_list = NULL;

    for (int i = 0; environ[i] != NULL; i++) {
        char *env_var = environ[i];
        char *equal_sign = ft_strchr(env_var, '=');

        if (equal_sign != NULL) {
            *equal_sign = '\0'; // Séparer la clé du reste de la chaîne
            char *name = env_var;
            char *value = equal_sign + 1;

            add_to_env_var_list(&env_list, name, value);
        }
    }

    return env_list;
}

int main(int argc, char *argv[], char *envp[]) {
    env_var_list *env_list = parse_environment(envp);

    // Parcours de la liste chaînée pour afficher les clés et les valeurs
    env_var_list *current = env_list;
    while (current != NULL) {
        printf("Name: %s, Value: %s\n", current->name, current->value);
        current = current->next;
    }

    // Libération de la mémoire
    current = env_list;
    while (current != NULL) {
        env_var_list *temp = current;
        current = current->next;
        free(temp->name);
        free(temp->value);
        free(temp);
    }

    return 0;
}
