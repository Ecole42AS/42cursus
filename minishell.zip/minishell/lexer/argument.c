/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   argument.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: astutz <astutz@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/29 19:41:18 by astutz            #+#    #+#             */
/*   Updated: 2023/09/02 19:05:27 by astutz           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"

void add_to_argument_list(argument_list **list, tokens *token)
{
	argument_list *new_node = malloc(sizeof(argument_list));
	if (!new_node)
	{
		perror("Issue malloc add_to_argument_list");
		exit(EXIT_FAILURE);
	}

	new_node->argument = strdup(token->token);
	if (!new_node->argument)
	{
		perror("Issue strdup add_to_argument_list");
		free(new_node);
		exit(EXIT_FAILURE);
	}

	new_node->next = *list;
	*list = new_node;
}

// void get_argument(t_token *token, char *input)
// {
// 	int start = token->i;
// 	int end = start;

// 	while (input[end] && !isspace(input[end]))
// 	{
// 		end++; // Avance jusqu'à rencontrer un espace ou la fin de la chaîne
// 	}

// 	// Allouer de la mémoire pour stocker l'argument
// 	token->argument = malloc(sizeof(char) * (end - start + 1));
// 	if (!token->argument)
// 	{
// 		perror("Issue malloc get_argument");
// 		exit(EXIT_FAILURE);
// 	}

// 	// Copier l'argument dans la nouvelle chaîne
// 	int j = 0;
// 	for (int i = start; i < end; i++)
// 	{
// 		token->argument[j] = input[i];
// 		j++;
// 	}
// 	token->argument[j] = '\0'; // Terminer la chaîne

// 	// Ajouter l'argument à la liste chaînée arguments
// 	add_to_argument_list(&(token->argument), token);

// 	// Mettre à jour l'index pour pointer au caractère après l'argument
// 	token->i = end;
// }
