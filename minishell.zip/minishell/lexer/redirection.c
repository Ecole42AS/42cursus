/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   redirection.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: astutz <astutz@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/29 19:36:58 by astutz            #+#    #+#             */
/*   Updated: 2023/09/02 18:59:30 by astutz           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"

// bool is_redirection(char c)
// {
// 	// Vérifiez si le caractère c est une redirection ("<" ou ">")
// 	return (c == '<' || c == '>');
// }

// void get_redirection(t_token *token, char *input) {
//     if (input[token->i + 1] == '>') {
//         token->redirection = malloc(sizeof(char) * 3);
//         if (!token->redirection) {
//             perror("Problème malloc get_redirection");
//             exit(EXIT_FAILURE);
//         }
//         token->redirection[0] = input[token->i];
//         token->redirection[1] = input[token->i + 1];
//         token->redirection[2] = '\0';
//         token->i += 2; // Passer aux deux prochains caractères après la redirection
//     } 
//     else if (input[token->i + 1] == '<') {
//         // Gérer le cas de '<<'
//         token->redirection = malloc(sizeof(char) * 3);
//         if (!token->redirection) {
//             perror("Problème malloc get_redirection");
//             exit(EXIT_FAILURE);
//         }
//         token->redirection[0] = input[token->i];
//         token->redirection[1] = input[token->i + 1];
//         token->redirection[2] = '\0';
//         token->i += 2; // Passer aux deux prochains caractères après la redirection
//     } else {
//         token->redirection = malloc(sizeof(char) * 2);
//         if (!token->redirection) {
//             perror("Issue malloc get_redirection");
//             exit(EXIT_FAILURE);
//         }
//         token->redirection[0] = input[token->i]; // Copiez le caractère "<" ou ">"
//         token->redirection[1] = '\0';
//         token->i++; // Passez au prochain caractère après la redirection
//     }
// }


// void add_to_redirection_list(redirection_list **list, t_token *token)
// {
// 	redirection_list *new_node = malloc(sizeof(redirection_list));
// 	if (!new_node)
// 	{
// 		perror("Issue malloc add_to_redirection_list");
// 		exit(EXIT_FAILURE);
// 	}

// 	new_node->redirection = strdup(token->redirection);
// 	if (!new_node->redirection)
// 	{
// 		perror("Issue strdup add_to_redirection_list");
// 		free(new_node);
// 		exit(EXIT_FAILURE);
// 	}

// 	new_node->next = *list;
// 	*list = new_node;
// }

void add_to_double_outputfile_list(double_outputfile **list, tokens *token) {
    double_outputfile *new_node;
	new_node = malloc(sizeof(double_outputfile));
    if (!new_node) {
        perror("Problème d'allocation mémoire dans add_to_double_outputfile");
        exit(EXIT_FAILURE);
    }

    new_node->double_outputfile_content = ft_strdup(token->token);
    if (!new_node->double_outputfile_content) {
        perror("Problème de duplication de la chaîne dans add_to_double_outputfile");
        free(new_node);
        exit(EXIT_FAILURE);
    }

    new_node->next = *list;
    *list = new_node;
}

void add_to_outputfile_list(outputfile **list, tokens *token) {
    outputfile *new_node;
	new_node = malloc(sizeof(outputfile));
    if (!new_node) {
        perror("Problème d'allocation mémoire dans add_to_outputfile");
        exit(EXIT_FAILURE);
    }

    new_node->outputfile_content = ft_strdup(token->token);
    if (!new_node->outputfile_content) {
        perror("Problème de duplication de la chaîne dans add_to_outputfile");
        free(new_node);
        exit(EXIT_FAILURE);
    }

    new_node->next = *list;
    *list = new_node;
}
void add_to_inputfile_list(inputfile **list, tokens *token) {
    inputfile *new_node;
	new_node = malloc(sizeof(inputfile));
    if (!new_node) {
        perror("Problème d'allocation mémoire dans add_to_inputfile");
        exit(EXIT_FAILURE);
    }

    new_node->inputfile_content = ft_strdup(token->token);
    if (!new_node->inputfile_content) {
        perror("Problème de duplication de la chaîne dans add_to_inputfile");
        free(new_node);
        exit(EXIT_FAILURE);
    }

    new_node->next = *list;
    *list = new_node;
}

void add_to_double_inputfile_list(double_inputfile **list, tokens *token) {
    double_inputfile *new_node = malloc(sizeof(double_inputfile));
    if (!new_node) {
        perror("Problème d'allocation mémoire dans add_to_double_inputfile");
        exit(EXIT_FAILURE);
    }

    new_node->double_inputfile_content = ft_strdup(token->token);
    if (!new_node->double_inputfile_content) {
        perror("Problème de duplication de la chaîne dans add_to_double_inputfile");
        free(new_node);
        exit(EXIT_FAILURE);
    }

    new_node->next = *list;
    *list = new_node;
}

