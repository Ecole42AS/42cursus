/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   command.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: astutz <astutz@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/29 19:38:49 by astutz            #+#    #+#             */
/*   Updated: 2023/09/02 10:27:18 by astutz           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../minishell.h"

bool is_command(const char *name) {
    static const char *commands[] = {
        "echo",
        "cd",
        "pwd",
        "export",
        "unset",
        "env",
        "exit"
    };

    size_t i = 0;
    while (i < sizeof(commands) / sizeof(commands[0])) {
        if (ft_strcmp(name, commands[i]) == 0) {
            return true;
        }
        i++;
    }

    return false;
}

// if (is_command(new->cmd)) {
//     new->type = COMMAND;
// } else {
//     // Traiter le token comme autre chose (argument, option, etc.)
// }
void get_command(t_token *token, const char *input) {
    int start = token->i;
    int end = token->i;

    // Parcourir la chaîne jusqu'à ce qu'un espace ou la fin de la chaîne soit trouvé
    while (input[end] != '\0' && !ft_is_space(input[end])) {
        end++;
    }

    // Extraire la sous-chaîne correspondant à la commande
    // char *command = strndup(input + start, end - start);
	char *command = ft_substr(input, start, end - start);
    if (!command) {
        perror("Issue substr in get_command");
        exit(EXIT_FAILURE);
    }

    // Vérifier si la sous-chaîne est une commande valide
    if (is_command(command)) {
        token->type = COMMAND;
        token->command = command;
    } else {
        // Traiter le token comme autre chose (argument, option, etc.)
        free(command);
    }

    // Mettre à jour l'index du token
    token->i = end;
}


void add_to_command_list(command_list **list, char *command)
{
	command_list *new_node = malloc(sizeof(command_list));
	if (!new_node)
	{
		perror("Issue malloc add_to_command_list");
		exit(EXIT_FAILURE);
	}

	new_node->command = command;
	new_node->next = *list;
	*list = new_node;
}
