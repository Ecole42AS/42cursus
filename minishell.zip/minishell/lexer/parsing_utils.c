/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parsing_utils.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: astutz <astutz@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/04 19:02:16 by astutz            #+#    #+#             */
/*   Updated: 2023/09/05 21:11:31 by astutz           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"

void parser(char **words, t_pars *parsing)
{
	int i;
	int is_cmd_or_prog;
	const char *builtins[] = {
    "echo",
    "cd",
    "pwd",
    "export",
    "unset",
    "env",
    "exit"
	};
    // t_pars *parsing = (t_pars *)malloc(sizeof(t_pars));
    // if (parsing == NULL) {
    //     perror("memory allocation failure");
    // }
	i = -1;
	is_cmd_or_prog = 0; //si un commande a deja ete trouve
	// initialize_parsing(parsing);//mettre le current Node comme param
	while (words[++i]) //ajouter && words[i] != '|'
	{
		if (words[i][0] == '<') //!! plus tard si jamais pas d'espace
			if (words[i][1] == '\0')
			{
				parsing->infile = open(words[i + 1], O_RDONLY); //ATTENTION: verifier si c est le dernier fichier qu il retourne!
				if (parsing->infile < 0)
					perror("Couldn't open the file");
			}
			else
			{
				parsing->infile = open(&words[i][i + 1], O_RDONLY);
				if (parsing->infile < 0)
					perror("Couldn't open the file");
			}
		else if (words[i][0] == '>') //!! plus tard si jamais pas d'espace
			if (words[i][1] == '\0')
			{
				parsing->outfile = open(words[i + 1], O_CREAT | O_WRONLY | O_TRUNC, 0777); //ATTENTION: verifier si c est le dernier fichier qu il retourne!
				if (parsing->outfile < 0)
					perror("Couldn't open the file");
			}
			else
			{
				parsing->outfile = open(&words[i][i + 1], O_CREAT | O_WRONLY | O_TRUNC, 0777); //parsing->outfile = open(words[i + 1], O_WRONLY | O_CREAT | O_TRUNC, 0644); // Utilisation correcte d'open pour la sortie
				if (parsing->outfile < 0)
					perror("Couldn't open the file");
			}
		else if (!strncmp(words[i], "<<", 2))//Attention implémenter le cas si il n y a pas d espace après <<
		{
			// char *sequence_de_fin = words[i + 1]; // implémenter sans espaces
			// char *here_document = NULL;
			// char *ligne = NULL;
			// int here_doc;
			// size_t taille_here_document = 0;
			// char *here_document = calloc(1000, sizeof(char)); // est ce que je peux changer 1000 par taille du heredoc
			// if (here_document == NULL)
			// {
			// 	perror("Erreur d'allocation mémoire");
			// 	exit(1);
			// }
			// here_doc = open(".here_doc.txt", O_CREAT | O_RDWR | O_TRUNC, 0777);
			// if (!here_doc)
			// {
			// 	perror("error creating here_doc file");
			// 	exit(1);
			// }
			// ligne = get_next_line(here_doc);
			// while ()
			// {
			// 	ligne = get_next_line(here_doc)
			//     if (strcmp(ligne, sequence_de_fin) == 0)
			//         break;
			// 	ft_strlcat(here_document, line, ft_strlen(line));
			// 	taille_here_document += strlen(ligne);
			// 	free(line);
			// };
			char	*heredoc_buffer;
			
			parsing->infile = open(".heredoc.txt", O_CREAT | O_RDWR | O_TRUNC, 0777);
			if (!parsing->infile)
			{
				perror("error creating heredoc file");
				return ;
			}
			heredoc_buffer = readline("> ");
			while (heredoc_buffer && !strncmp(words[i + 1], heredoc_buffer, strlen(words[i + 1])))
			{
				write(parsing->infile, heredoc_buffer, ft_strlen(heredoc_buffer));
				write(parsing->infile, "\n", 1);
				free(heredoc_buffer);
				heredoc_buffer = readline("> ");
			}
			close(parsing->infile);
			free(heredoc_buffer);
		}
		else if (!strncmp(words[i], ">>", 2))
        {
         //!! plus tard si jamais pas d'espace, //A IMPLEMENTER
			parsing->outfile = open(words[i + 1], O_WRONLY | O_CREAT | O_APPEND);
			if (parsing->infile < 0)
				perror("Couldn't open the file");
        }
		else if (!strncmp(words[i], "./", 2))
        {
			parsing->cmd = words[i] + 2;
			parsing->type = 'P';
			is_cmd_or_prog = 1;
        }
        // A ce moment dans le code, la commande est forcement le premier element qui n a pas encore ete traiter
		else if (is_cmd_or_prog == 0)
        {
			parsing->cmd = words[i];
			is_cmd_or_prog = 1;
			if (!strncmp(words[i], builtins[i], strlen(words[i])))
				parsing->type = 'B';
			else
				parsing->type = 'C';
        }
		else
			parsing->arg = words[i];
	}
	
        // free(parsing);
}