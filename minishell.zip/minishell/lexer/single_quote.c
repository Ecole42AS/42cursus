/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   single_quote.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: astutz <astutz@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/29 19:34:57 by astutz            #+#    #+#             */
/*   Updated: 2023/09/02 16:47:01 by astutz           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"

char *get_content_inside_single_quotes(const char *input) {
    int start = 0;
    int end = 0;
    int length = ft_strlen(input);

    // Recherche du premier guillemet simple ouvrant
    while (start < length && input[start] != '\'') {
        start++;
    }

    // Recherche du premier guillemet simple fermant
    end = start + 1;
    while (end < length && input[end] != '\'') {
        end++;
    }

    // Vérification de la présence de guillemets simples ouvrants et fermants
    if (start >= length || end >= length || input[start] != '\'' || input[end] != '\'') {
        fprintf(stderr, "Erreur : Guillemets simples non appariés.\n");
        return NULL;
    }

    // Allouer de la mémoire pour le contenu entre guillemets simples
    char *content = (char *)malloc(sizeof(char) * (end - start));
    if (!content) {
        perror("Allocation de mémoire échouée");
        exit(EXIT_FAILURE);
    }

    // Copier le contenu entre guillemets simples dans la nouvelle chaîne
    int i, j = 0;
    for (i = start + 1; i < end; i++) {
        content[j] = input[i];
        j++;
    }
    content[j] = '\0'; // Terminer la chaîne

    return content;
}

void add_to_single_quote_list(single_quote_list **list, tokens *token)
{
	single_quote_list *new_node = malloc(sizeof(single_quote_list));
	if (!new_node)
	{
		perror("Issue malloc add_to_single_quote_list");
		exit(EXIT_FAILURE);
	}

	new_node->single_quote_content = ft_strdup(token->token); // Assuming content is a string
	if (!new_node->single_quote_content)
	{
		perror("Issue strdup add_to_single_quote_list");
		free(new_node);
		exit(EXIT_FAILURE);
	}

	new_node->next = *list;
	*list = new_node;
}

// int main() {
//     char *input = "'Contenu entre guillemets simples'";
//     char *content = get_content_inside_single_quotes(input);

//     if (content) {
//         printf("Contenu entre guillemets simples : %s\n", content);
//         free(content); // N'oubliez pas de libérer la mémoire allouée
//     }

//     return 0;
// }