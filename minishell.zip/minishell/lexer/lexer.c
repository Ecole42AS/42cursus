#include "../minishell.h"


void initialize_token(t_token *token, env_var_list *env, int i) {
    token->command = NULL;  // Initialiser le pointeur de commande à NULL
    token->type = UNKNOWN;  // Initialiser le type à une valeur par défaut
    token->env = env;  // Initialiser le pointeur vers l'environnement
    token->i = i;  // Initialiser l'i de la séquence
    token->single_quote_content = NULL;  // Initialiser le contenu entre single quotes à NULL
    token->double_quote_content = NULL;  // Initialiser le contenu entre double quotes à NULL
    token->env_var_name = NULL;  // Initialiser la variable d'environnement à NULL
    token->env_var_value = NULL;  // Initialiser la variable d'environnement à NULL
    token->argument = NULL;  // Initialiser l'argument à NULL
    token->next = NULL;  // Initialiser le pointeur suivant à NULL
    // Initialiser d'autres membres si nécessaire
}

//  && input[index] != '|'
// Fonction de lexing pour séparer l'entrée en tokens
void lexer(char *input, env_var_list *env, command_line **line) {
    t_token *token = NULL;
    int i = 0;
	// char **cmd;

	// static const char *commands[] = {
    //     "echo",
    //     "cd",
    //     "pwd",
    //     "export",
    //     "unset",
    //     "env",
    //     "exit"
    // };

	// while(commands[i])
	// {
	// 	*cmd = ft_strnstr(input, commands[i], ft_strlen(commands[i]));
	// 	add_to_command_list(commands, cmd);
	// 	i++;
	// }

	// ft_substr


    while (input[i] != '\0') {
        // Créer un nouveau token
        token = malloc(sizeof(t_token));
        initialize_token(token, env, i);

        // Identifier et traiter le type de token (commande, argument, etc.)
        if (token[i] == '\'') {
            get_single_quote_content(token, input);
            add_to_single_quote_list(&((*line)->single_quote_contents), token);
        } else if (input[i] == '"') {
            get_double_quote_content(token, input);
            add_to_double_quote_list(&((*line)->double_quote_contents), token);
        // } else if (is_command(cmd)) {
        //     get_command(token, input);
        //     add_to_command_list(commands, token);
        } else if (is_redirection(input[i])) {
            get_redirection(token, input);
            add_to_redirection_list(&((*line)->redirections), token);
        // } else if (is_env_var(input[i])) {
        //     get_env_var(token, input);
        //     add_to_env_var_list(&((*line)->variables), token);
        } else {
            // Si ce n'est aucun des cas ci-dessus, c'est probablement un argument
            get_argument(token, input);
            add_to_argument_list(&((*line)->arguments), token);
        }

        // Aller au prochain caractère non traité
        i = token->i;
    }
}

int main() {
    char input[] = "echo 'Hello, world!'";

    // Créer une structure pour stocker les tokens
    t_token *tokens = NULL;
	env_var_list *env = malloc(sizeof(env_var_list));

    // Appeler la fonction lexer pour générer les tokens
    lexer(input, env, &tokens);


    // Afficher les tokens
	// void display_tokens(t_token *tokens) {
	// 	t_token *current = tokens;
		
	// 	while (current != NULL) {
	// 		// En fonction du type de token (current->type), affichez les données appropriées (current->data)
	// 		// Par exemple, pour un token de type "commande", affichez le nom de la commande, etc.
			
	// 		current = current->next;
	// 	}
	// }
		print_linked_list(tokens);


    // Libérer la mémoire utilisée par les tokens
	// void free_tokens(t_token *tokens) 
	// {
	// 	t_token *current = tokens;
		
	// 	while (current != NULL) 
	// 	{
	// 		// Libérez la mémoire utilisée par les données spécifiques au token (current->data)
	// 		// Libérez le token lui-même
			
	// 		t_token *temp = current;
	// 		current = current->next;
	// 		free(temp);
	// 	}
	// }
    // free_tokens(tokens);

    return 0;
}