/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   testlexer2.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: astutz <astutz@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/01 16:07:40 by astutz            #+#    #+#             */
/*   Updated: 2023/09/04 21:10:10 by astutz           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"



char **lexer(char *input)
{
    char **word;
    int i = 0;
    int j = 0;
    int start = 0;
    int end = 0;
    int nb_words = 0;

    while (input[i])
    {
        while (ft_is_space(input[i]) == 1 && input[i])
            i++;
        start = i;
        while (!ft_is_space(input[i]) && input[i])
            i++;
        end = i;
        nb_words++;
    }

    word = (char **)calloc(nb_words + 1, sizeof(char *)); //Voir d ou provient le leak
    if (!word)
    {
        perror("Allocation de mémoire échouée");
        exit(1);
    }

    i = 0;
    while (input[i])
    {
        while (ft_is_space(input[i]) == 1 && input[i])
            i++;
        start = i;
        while (!ft_is_space(input[i]) && input[i])
            i++;
        end = i;
        word[j] = ft_substr(input, start, end - start);
        j++;
    }
    word[j] = NULL;

    return (word);
	free(word); //a voir
}

// int main()
// {
//     char *input;
//     char **tab;
//     int i;

//     i = 0;
//     input = "	 hello   World  44 | 'gegd' ";
//     tab = lexer(input);
//     while (tab[i])
//     {
//         printf("%s\n", tab[i]);
//         i++;
//     }

//     // Libérer la mémoire allouée
//     for (int k = 0; tab[k]; k++)
//     {
//         free(tab[k]);
//     }
//     free(tab);

//     return 0;
// }

// #include <stdio.h>
// #include <stdlib.h>
// #include <string.h>

// // Définissez vos fonctions et structures personnalisées ici si nécessaire

// int main(int argc, char **argv)
// {
//     char *input = "	 hello   World  44 | 'gegd' "; // Exemple de ligne de commande
//     char **words = lexer(input);

//     char **commandes = NULL;
//     char **programmes = NULL;
//     char **infile = NULL;
//     char **dinfile = NULL;
//     char **outfile = NULL;
//     char **doutfile = NULL;
//     char **arguments = NULL;

//     int i = 0;
//     int j = 0;
//     int k = 0;
//     int is_programme = 1; // On commence par les programmes

//     while (words[i])
//     {
//         if (strcmp(words[i], "|") == 0)
//         {
//             is_programme = 1;
//             i++; // Passe au mot suivant après le pipe
//         }
//         else if (strcmp(words[i], ">") == 0)
//         {
//             outfile = realloc(outfile, (k + 2) * sizeof(char *));
//             outfile[k] = words[i + 1];
//             outfile[k + 1] = NULL;
//             i += 2; // Passe au mot suivant après le ">"
//         }
//         else if (strcmp(words[i], ">>") == 0)
//         {
//             doutfile = realloc(doutfile, (k + 2) * sizeof(char *));
//             doutfile[k] = words[i + 1];
//             doutfile[k + 1] = NULL;
//             i += 2; // Passe au mot suivant après le ">>"
//         }
//         else if (strcmp(words[i], "<") == 0)
//         {
//             infile = realloc(infile, (k + 2) * sizeof(char *));
//             infile[k] = words[i + 1];
//             infile[k + 1] = NULL;
//             i += 2; // Passe au mot suivant après le "<"
//         }
//         else if (strcmp(words[i], "<<") == 0)
//         {
//             dinfile = realloc(dinfile, (k + 2) * sizeof(char *));
//             dinfile[k] = words[i + 1];
//             dinfile[k + 1] = NULL;
//             i += 2; // Passe au mot suivant après le "<<"
//         }
//         else
//         {
//             if (is_programme)
//             {
//                 programmes = realloc(programmes, (j + 2) * sizeof(char *));
//                 programmes[j] = words[i];
//                 programmes[j + 1] = NULL;
//                 j++;
//             }
//             else
//             {
//                 arguments = realloc(arguments, (k + 2) * sizeof(char *));
//                 arguments[k] = words[i];
//                 arguments[k + 1] = NULL;
//                 k++;
//             }
//             i++;
//         }
//     }

//     // Affichez ou utilisez les différents types de mots
//     printf("Commandes:\n");
//     // Traitez les commandes ici (s'il y en a)

//     printf("Programmes:\n");
//     for (int l = 0; programmes[l]; l++)
//     {
//         printf("%s\n", programmes[l]);
//     }

//     printf("Infile:\n");
//     for (int l = 0; infile[l]; l++)
//     {
//         printf("%s\n", infile[l]);
//     }

//     printf("Dinfile:\n");
//     for (int l = 0; dinfile[l]; l++)
//     {
//         printf("%s\n", dinfile[l]);
//     }

//     printf("Outfile:\n");
//     for (int l = 0; outfile[l]; l++)
//     {
//         printf("%s\n", outfile[l]);
//     }

//     printf("Doutfile:\n");
//     for (int l = 0; doutfile[l]; l++)
//     {
//         printf("%s\n", doutfile[l]);
//     }

//     printf("Arguments:\n");
//     for (int l = 0; arguments[l]; l++)
//     {
//         printf("%s\n", arguments[l]);
//     }

//     // Libérer la mémoire allouée
//     for (int l = 0; words[l]; l++)
//     {
//         free(words[l]);
//     }
//     free(words);

//     free(commandes);
//     free(programmes);
//     free(infile);
//     free(dinfile);
//     free(outfile);
//     free(doutfile);
//     free(arguments);

//     return 0;
// }


