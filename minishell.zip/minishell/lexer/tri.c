/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tri.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: astutz <astutz@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/01 16:32:06 by astutz            #+#    #+#             */
/*   Updated: 2023/09/01 16:43:52 by astutz           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"

faire fonction check si les squotes ou les dquotes sont pairs ou impair
if ((tokens[i][j] == '/"' || tokens[i][j] == "'") && check_quotes() == 1)
	lire seulement ce qu il y a a l interieur des quotes
si c est une commande, ajouter dans la liste cmd autrement dans arguments.

