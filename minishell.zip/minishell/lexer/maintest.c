/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   maintest.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: astutz <astutz@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/03 17:36:17 by astutz            #+#    #+#             */
/*   Updated: 2023/09/03 19:31:34 by astutz           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <readline/readline.h>
#include <readline/history.h>
//USE gcc -lreadline maintest.c 
// (A mettre dans le .h)
typedef struct parsing
{
	int id; // si il y a des pipes,
	int infile;
	int outfile;
	char *cmd;
	char type; //C = commande, P = program, B = builtin
	char *arg;
	struct parsing *next;
} t_pars;


// Un Node par pipe(A mettre dans un fichier d initialisation.c)
void initialize_parsing(t_pars *my_pars)
{
	if (my_pars != NULL)
	{
		my_pars->id = 1;
		my_pars->infile = 0;
		my_pars->outfile = 0;
		my_pars->cmd = NULL;
		my_pars->type = 0;
		my_pars->arg = NULL;
		my_pars->next = NULL;
	}
}

int main(int ac, char **av)
{
	char *buffer;
	while(1)
	{
		buffer = readline("\x1B[38;5;82mminishell$\x1B[0m ");
		if  (!strcmp (buffer, "exit"))
			break;
		// printf("Tu as dis: %s\n", buffer);
	}
	t_pars *parsing;
	int i;
	int is_cmd_or_prog;
	const char *builtins[] = {
    "echo",
    "cd",
    "pwd",
    "export",
    "unset",
    "env",
    "exit"
	};
	
	i = -1;
	is_cmd_or_prog = 0; //si un commande a deja ete trouve
	initialize_parsing(parsing);//mettre le current Node comme param
	while (av[++i])
	{
		if (av[i][0] == '<') //!! plus tard si jamais pas d'espace
			if (av[i][1] == '\0')
			{
				parsing->infile = open(av[i + 1], O_RDONLY); //ATTENTION: verifier si c est le dernier fichier qu il retourne!
				if (parsing->infile < 0)
					perror("Couldn't open the file");
			}
			else
			{
				parsing->infile = open(&av[i][i + 1], O_RDONLY);
				if (parsing->infile < 0)
					perror("Couldn't open the file");
			}
		else if (av[i][0] == '>') //!! plus tard si jamais pas d'espace
			if (av[i][1] == '\0')
			{
				parsing->outfile = open(av[i + 1], O_WRONLY, O_CREAT, O_TRUNC); //ATTENTION: verifier si c est le dernier fichier qu il retourne!
				if (parsing->outfile < 0)
					perror("Couldn't open the file");
			}
			else
			{
				parsing->outfile = open(&av[i][i + 1], O_WRONLY, O_CREAT, O_TRUNC); //parsing->outfile = open(av[i + 1], O_WRONLY | O_CREAT | O_TRUNC, 0644); // Utilisation correcte d'open pour la sortie
				if (parsing->outfile < 0)
					perror("Couldn't open the file");
			}
		// else if (!strncmp(av[i], "<<", 2))//!! plus tard si jamais pas d'espace
			// un autre ttruc;
		else if (!strncmp(av[i], ">>", 2)) //!! plus tard si jamais pas d'espace, //A IMPLEMENTER
			parsing->outfile = open(av[i + 1], O_WRONLY, O_CREAT, O_APPEND);
			if (parsing->infile < 0)
				perror("Couldn't open the file");
		else if (!strncmp(av[i], "->/", 2))
			parsing->cmd = av[i] + 2;
			parsing->type = 'P';
			is_cmd_or_prog = 1;
		else if (is_cmd_or_prog == 0) // A ce moment dans le code, la commande est forcement le premier element qui n a pas encore ete traiter
			parsing->cmd = av[i];
			is_cmd_or_prog = 1;
			if (!strncmp(av[i], builtins[i], strlen(av[i])))
				parsing->type = 'B';
			else
				parsing->type = 'C';
		else
			parsing->arg = av[i];
		
	}
}