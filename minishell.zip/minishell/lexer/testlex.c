// /* ************************************************************************** */
// /*                                                                            */
// /*                                                        :::      ::::::::   */
// /*   testlex.c                                          :+:      :+:    :+:   */
// /*                                                    +:+ +:+         +:+     */
// /*   By: astutz <astutz@student.42.fr>              +#+  +:+       +#+        */
// /*                                                +#+#+#+#+#+   +#+           */
// /*   Created: 2023/09/02 13:16:33 by astutz            #+#    #+#             */
// /*   Updated: 2023/09/02 14:07:23 by astutz           ###   ########.fr       */
// /*                                                                            */
// /* ************************************************************************** */

#include "../minishell.h"

// Fonction pour ajouter un token à la liste chaînée
void add_token(tokens **head, char *token) {
    tokens *new_node = (tokens *)malloc(sizeof(tokens));
    if (!new_node) {
        perror("Allocation de mémoire échouée");
        exit(1);
    }

    new_node->token = strdup(token);
    new_node->next = *head;
    *head = new_node;
}

// Fonction pour libérer la mémoire de la liste chaînée
void free_token_list(tokens *head) {
    while (head) {
        tokens *temp = head;
        head = head->next;
        free(temp->token);
        free(temp);
    }
}

// Fonction lexer qui retourne une liste chaînée de tokens
tokens *lexer(char *input) {
    tokens *head = NULL;
    int i = 0;
    int start = 0;
    int end = 0;

    while (input[i]) {
        while (input[i] == ' ' || input[i] == '\t') {
            i++;
        }
        start = i;
        while (input[i] && input[i] != ' ' && input[i] != '\t') {
            i++;
        }
        end = i;

        if (start != end) {
            char *token = ft_strndup(&input[start], end - start);
            add_token(&head, token);
        }
    }

    return (head);
}

int main(int argc, char **argv) {
    char 				*input;
    char 				*content;
    tokens				*token_list;
	single_quote_list 	*single_quote_list = NULL; // Déclaration de la liste chaînée single_quote_list
	double_quote_list 	*double_quote_list = NULL; // Déclaration de la liste chaînée double_quote_list
	double_outputfile 	*double_outputfile = NULL;
	double_inputfile 	*double_inputfile = NULL;
	argument_list 		*argument = NULL;
	inputfile			*input_file_content;
	outputfile			*outputfile_content;

    input = "	'hello'   >>	 <<  <   <     World  44 | 'gegd' ";
    token_list = lexer(input);

    // Parcourez la liste chaînée et affichez les tokens
	tokens *current = token_list;
	while (current) {
    // Vérifiez si le token commence par un guillemet simple
		printf("Token actuel : \"%s\"\n", current->token);
		if (current->token[0] == '\'') {
			char *content = get_content_inside_single_quotes(current->token);
			if (content) {
				printf("Contenu entre guillemets simples : %s\n", content);
				
				// Ajoutez le contenu à la liste chaînée single_quote_list
				add_to_single_quote_list(&single_quote_list, current);
				
				// Libérez la mémoire allouée pour le contenu
				free(content);
			}
		}
		else if (current->token[0] == '\"') {
			char *content = get_content_inside_double_quotes(current->token);
			if (content) {
				printf("Contenu entre guillemets doubles : %s\n", content);
				
				// Ajoutez le contenu à la liste chaînée single_quote_list
				add_to_double_quote_list(&double_quote_list, current);
				
				// Libérez la mémoire allouée pour le contenu
				free(content);
			}
		// else if (strncmp(current->token, "<<", 2) == 0 && current->token[2] == '\0')  {
		// else if (current->token[0] == '>' && current->token[1] == '>')   {
		else if (!ft_strcmp(current->token, ">>"))   {
			char *content = ft_strdup(current->token);
			if (content) {
				printf("Contenu doubles outputfile: %s\n", content);
				
				// Ajoutez le contenu à la liste chaînée single_quote_list
				add_to_double_outputfile_list(&double_outputfile, current);
				// while(double_outputfile != NULL)
				// {
				// 	printf("double outputfile: %s\n", double_outputfile->double_outputfile_content);
				// 	double_outputfile = double_outputfile ->next;
				// }
				// Libérez la mémoire allouée pour le contenu
				free(content);
			}
		}
		// else if (current->token[0] == '<' && current->token[1] == '<')   {
		else if (!strcmp(current->token, "<<"))   {
			char *content = ft_strdup(current->token);
			// printf("content:%s", content);
			if (content) {
				printf("Contenu doubles inputfile: %s\n", content);
				add_to_double_inputfile_list(&double_inputfile, current);
				free(content);
			}
		}
		/*à implémenter*/
		else if (!ft_strcmp(current->token, "<"))   {
			char *content = ft_strdup(current->token);
			// printf("content:%s", content);
			if (content) {
				printf("Contenu inputfile: %s\n", content);
				add_to_inputfile_list(&input_file_content, current);
				free(content);
			}
		}
		else if (!ft_strcmp(current->token, ">"))   {
			char *content = ft_strdup(current->token);
			// printf("content:%s", content);
			if (content) {
				printf("Contenu outputfile: %s\n", content);
				add_to_outputfile_list(&outputfile_content, current);
				free(content);
			}
		}
		} else {
			char *content = ft_strdup(current->token);
			// printf("content:%s", content);
			if(content)
			{
				printf("Contenu argument: %s\n", content);
				add_to_argument_list(&argument, current);
				free(content);
			}
		}

    current = current->next;
	}
	argument_list *current_argument = argument;
while (current_argument != NULL) {
    printf("Argument : %s\n", current_argument->argument);
    current_argument = current_argument->next;
}
    // Libérez la mémoire allouée pour la liste chaînée
    free_token_list(token_list);

    return 0;
}
