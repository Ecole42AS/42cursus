/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parsing.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: astutz <astutz@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/02 10:16:35 by astutz            #+#    #+#             */
/*   Updated: 2023/09/06 14:44:10 by astutz           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"

int g_exit_code = 0;
/*Boucle infinie : Soyez prudent avec les boucles infinies. 
Dans un véritable shell, vous devriez avoir un moyen de quitter le programme proprement, pas seulement en tapant "exit".
Envisagez d'ajouter davantage de conditions de sortie.*/
int main()//Ajouter l'environnement et le allouer de la memoire(calloc)
{
	char *input;
	char **words;
	t_pars *parsing = (t_pars *)malloc(sizeof(t_pars));
    if (parsing == NULL) {
        perror("memory allocation failure");
    }
	initialize_parsing(parsing);
    /*input = calloc(1024, sizeof(char));
    if (!input)
    {
        perror("Memory allocation problem");
        exit(EXIT_FAILURE);
    }*/
	// init_termios();
	while(1)
	{
		// signals_init(signals_handle_input);
		input = readline("\x1B[38;5;82mminishell$\x1B[0m ");
		if (!strncmp(input, "quit", 4))
		// signals_init(signals_handle_execution);
			break;
		words = lexer(input);
		parser(words, parsing);
		// printf("Tu as dis: %s\n", input);
		add_history(input);
		free(input);
	}
	print_linked_list(parsing);
    free(input);
	free(parsing);
	// int i;
	// int is_cmd_or_prog;
	// const char *builtins[] = {
    // "echo",
    // "cd",
    // "pwd",
    // "export",
    // "unset",
    // "env",
    // "exit"
	// };
    // t_pars *parsing = (t_pars *)malloc(sizeof(t_pars));
    // if (parsing == NULL) {
    //     perror("memory allocation failure");
    // }
	// i = -1;
	// is_cmd_or_prog = 0; //si un commande a deja ete trouve
	// initialize_parsing(parsing);//mettre le current Node comme param
	// while (av[++i]) //ajouter && av[i] != '|'
	// {
	// 	if (av[i][0] == '<') //!! plus tard si jamais pas d'espace
	// 		if (av[i][1] == '\0')
	// 		{
	// 			parsing->infile = open(av[i + 1], O_RDONLY); //ATTENTION: verifier si c est le dernier fichier qu il retourne!
	// 			if (parsing->infile < 0)
	// 				perror("Couldn't open the file");
	// 		}
	// 		else
	// 		{
	// 			parsing->infile = open(&av[i][i + 1], O_RDONLY);
	// 			if (parsing->infile < 0)
	// 				perror("Couldn't open the file");
	// 		}
	// 	else if (av[i][0] == '>') //!! plus tard si jamais pas d'espace
	// 		if (av[i][1] == '\0')
	// 		{
	// 			parsing->outfile = open(av[i + 1], O_WRONLY, O_CREAT, O_TRUNC); //ATTENTION: verifier si c est le dernier fichier qu il retourne!
	// 			if (parsing->outfile < 0)
	// 				perror("Couldn't open the file");
	// 		}
	// 		else
	// 		{
	// 			parsing->outfile = open(&av[i][i + 1], O_WRONLY, O_CREAT, O_TRUNC); //parsing->outfile = open(av[i + 1], O_WRONLY | O_CREAT | O_TRUNC, 0644); // Utilisation correcte d'open pour la sortie
	// 			if (parsing->outfile < 0)
	// 				perror("Couldn't open the file");
	// 		}
	// 	// else if (!strncmp(av[i], "<<", 2))//!! plus tard si jamais pas d'espace
	// 		// un autre ttruc;
	// 	else if (!strncmp(av[i], ">>", 2))
    //     {
    //      //!! plus tard si jamais pas d'espace, //A IMPLEMENTER
	// 		parsing->outfile = open(av[i + 1], O_WRONLY, O_CREAT, O_APPEND);
	// 		if (parsing->infile < 0)
	// 			perror("Couldn't open the file");
    //     }
	// 	else if (!strncmp(av[i], "->/", 2))
    //     {
	// 		parsing->cmd = av[i] + 2;
	// 		parsing->type = 'P';
	// 		is_cmd_or_prog = 1;
    //     }
    //     // A ce moment dans le code, la commande est forcement le premier element qui n a pas encore ete traiter
	// 	else if (is_cmd_or_prog == 0)
    //     {
	// 		parsing->cmd = av[i];
	// 		is_cmd_or_prog = 1;
	// 		if (!strncmp(av[i], builtins[i], strlen(av[i])))
	// 			parsing->type = 'B';
	// 		else
	// 			parsing->type = 'C';
    //     }
	// 	else
	// 		parsing->arg = av[i];
    //     free(parsing);
	// }
}