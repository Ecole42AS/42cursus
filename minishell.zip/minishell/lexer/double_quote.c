/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   double_quote.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: astutz <astutz@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/29 19:35:55 by astutz            #+#    #+#             */
/*   Updated: 2023/09/02 16:52:32 by astutz           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"

void add_to_double_quote_list(double_quote_list **list, tokens *token) {
    double_quote_list *new_node = malloc(sizeof(double_quote_list));
    if (!new_node) {
        perror("Problème d'allocation mémoire dans add_to_double_quote_list");
        exit(EXIT_FAILURE);
    }

    new_node->double_quote_content = ft_strdup(token->token);
    if (!new_node->double_quote_content) {
        perror("Problème de duplication de la chaîne dans add_to_double_quote_list");
        free(new_node);
        exit(EXIT_FAILURE);
    }

    new_node->next = *list;
    *list = new_node;
}

char *get_content_inside_double_quotes(const char *input) {
    int start = 0;
    int end = 0;
    int length = strlen(input);

    // Recherche du premier guillemet double ouvrant
    while (start < length && input[start] != '"') {
        start++;
    }

    // Recherche du premier guillemet double fermant
    end = start + 1;
    while (end < length && input[end] != '"') {
        end++;
    }

    // Vérification de la présence de guillemets doubles ouvrants et fermants
    if (start >= length || end >= length || input[start] != '"' || input[end] != '"') {
        fprintf(stderr, "Erreur : Guillemets doubles non appariés.\n");
        return NULL;
    }

    // Allouer de la mémoire pour le contenu entre guillemets doubles
    char *content = (char *)malloc(sizeof(char) * (end - start));
    if (!content) {
        perror("Allocation de mémoire échouée");
        exit(EXIT_FAILURE);
    }

    // Copier le contenu entre guillemets doubles dans la nouvelle chaîne
    int i, j = 0;
    for (i = start + 1; i < end; i++) {
        content[j] = input[i];
        j++;
    }
    content[j] = '\0'; // Terminer la chaîne

    return content;
}
