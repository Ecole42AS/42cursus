/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   initialize.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: astutz <astutz@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/04 18:53:05 by astutz            #+#    #+#             */
/*   Updated: 2023/09/04 19:02:52 by astutz           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"

void initialize_parsing(t_pars *my_pars)
{
	if (my_pars != NULL)
	{
		my_pars->id = 1;
		my_pars->infile = 0;
		my_pars->outfile = 0;
		my_pars->cmd = NULL;
		my_pars->type = 0;
		my_pars->arg = NULL;
		my_pars->next = NULL;
	}
}