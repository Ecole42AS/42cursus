#include "minishell.h"


char *append(char *str1, char*str2)
{
    strcat(str1, " ");
    strcat(str1, str2);
    return (str1);
}

int main(int argc, char **argv)
{
    int i;
    char *values[];
    char *type[];
    char **vals;
    char **ty;
    char ***arg[2];
    int CP;
    char *args[];

    CP = 0;
    arg[0] = vals;
    arg[1] = ty;
    while (argv[i])
    {
        if (!strcmp(str[i], "<")
        {
            append(values, argv[i+1]);
            append(values, "I");
            i+=2;
        }
        else if (!strcmp(str[i], ">")
        {
            append(values, argv[i+1]);
            append(values, "O");
            i+=2;
        }
        else if (!strcmp(str[i], "./" && CP == 0)
        {
            append(values, argv[i+1]);
            append(values, "P");
            i+=2;
            CP = 1;
        }
        else if (CP == 0)
        {
            append(values, argv[i]);
            append(values, "C");     
            i++;
        } 
        else 
            append(args, argv[i])
    }
    vals = ft_split(values, " ");
    ty = ft_split(types, " ");

}