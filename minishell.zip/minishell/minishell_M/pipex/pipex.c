/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   pipex.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mde-sepi <marvin@42lausanne.ch>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/29 11:42:10 by mde-sepi          #+#    #+#             */
/*   Updated: 2022/11/29 11:42:22 by mde-sepi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include "pipex.h"

/*
Free: 	- get next line output
		- split output
TODO:	here_doc
		make open empty file2 if it exists
*/

void	extract_location(int fd[2], char *name)
{
	char	*arg[3];
	int		temp;

	arg[0] = "whereis";
	arg[1] = name;
	arg[2] = NULL;
	temp = dup(STDIN_FILENO);
	close(fd[0]);
	dup2(fd[1], STDOUT_FILENO);
	execve("/usr/bin/whereis", arg, NULL);
	write(temp, "extract location fail: ", 23);
	write(temp, name, ft_strlen(name));
	write(temp, "\n", 1);
	exit(1);
}

void	mid_gen(char *argv, int fgc[2], int fd[2], int temp)
{
	int		fex[2];
	pid_t	pid;
	char	**args;

	args = ft_split(argv, ' ');
	pipe(fex);
	pid = fork();
	if (pid == 0)
		extract_location(fex, args[0]);
	wait(NULL);
	close(fex[1]);
	in_out(fgc, fd, 0, NULL);
	execve(get_next_line(fex[0]), args, NULL);
	exec_fail(temp, argv, args);
}

void	first_gen(char **argv, int gen, int fd[2], int temp)
{
	int		fex[2];
	pid_t	pid;
	char	**args;

	args = ft_split(argv[gen + 1], ' ');
	pipe(fex);
	pid = fork();
	if (pid == 0)
		extract_location(fex, args[0]);
	wait(NULL);
	in_out(fex, fd, 1, argv[1]);
	execve(get_next_line(fex[0]), args, NULL);
	exec_fail(temp, argv[gen + 1], args);
}

// pipe out: fd, pipe in: fgc from child or fileint
void	grandchild(int fd[2], int gen, char **argv)
{
	int		fgc[2];
	pid_t	pid;
	int		temp;

	temp = dup(STDOUT_FILENO);
	if (gen > 1)
	{
		pipe(fgc);
		pid = fork();
		if (pid == 0)
			grandchild(fgc, gen - 1, argv);
		wait(NULL);
		mid_gen(argv[gen + 1], fgc, fd, temp);
	}
	else
		first_gen(argv, gen, fd, temp);
}

int	main(int argc, char **argv)
{
	int		fd[2];
	int		fex[2];
	pid_t	pid;
	char	**args;
	int		temp;

	temp = dup(STDOUT_FILENO);
	checks(argc, argv);
	pipe(fd);
	pid = fork();
	if (pid == 0)
		grandchild(fd, argc - 4, argv);
	wait(NULL);
	args = ft_split(argv[argc - 2], ' ');
	pipe(fex);
	pid = fork();
	if (pid == 0)
		extract_location(fex, args[0]);
	wait(NULL);
	in_out(fd, fex, 2, argv[argc - 1]);
	close(fd[0]);
	execve(get_next_line(fex[0]), args, NULL);
	exec_fail(temp, argv[argc - 2], args);
}
