/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   pip_utilities.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mde-sepi <marvin@42lausanne.ch>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/29 11:42:10 by mde-sepi          #+#    #+#             */
/*   Updated: 2022/11/29 11:42:22 by mde-sepi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include "pipex.h"

void	checks(int argc, char **argv)
{
	int		fd;
	mode_t	mode;

	if (argc < 5)
	{
		write(1, "Missing arguments\n", 18);
		exit(1);
	}
	fd = open(argv[1], O_RDONLY);
	if (fd == -1)
	{
		write(1, "Missing valid file 1\n", 21);
		exit(1);
	}
	close(fd);
	mode = S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IWOTH | S_IROTH;
	fd = open(argv[argc - 1], O_RDWR | O_CREAT | O_TRUNC, mode);
	if (fd == -1)
	{
		write(1, "Missing valid file 2\n", 21);
		exit(1);
	}
	close(fd);
}

void	exec_fail(int temp, char *str, char **args)
{
	int	i;

	i = 0;
	write(temp, "command not found: ", 19);
	write(temp, str, ft_strlen(str));
	write(temp, "\n", 1);
	while (args[i])
	{
		free(args[i]);
		i++;
	}
	free(args);
	exit(1);
}

void	in_out(int in[2], int out[2], int file_in_out, char *argv)
{
	if (file_in_out == 0)
	{
		close(out[0]);
		close(in[1]);
		dup2(in[0], STDIN_FILENO);
		dup2(out[1], STDOUT_FILENO);
	}
	else if (file_in_out == 1)
	{
		close(in[1]);
		close(out[0]);
		dup2(out[1], STDOUT_FILENO);
		dup2(open(argv, O_RDONLY), STDIN_FILENO);
	}
	else
	{
		close(out[1]);
		close(in[1]);
		dup2(open(argv, O_WRONLY), STDOUT_FILENO);
		dup2(in[0], STDIN_FILENO);
	}
}

int	ft_strlen(const char *str)
{
	int	a;

	a = 0;
	while (str[a])
		a++;
	return (a);
}
