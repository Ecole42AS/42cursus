#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv)
{
    int i;
    i = atoi(argv[1]);

    while (i > atoi(argv[1]) - 10)
    {
        printf("%d\n", i);
        i--;
    }
}