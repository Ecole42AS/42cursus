#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include "pipex.h"

/*int main() //pipe test
{
	int fd[2];
	pid_t pid;
	char buffer[14];
	char *args[2];
 
	if (pipe(fd) == -1)
	{
		perror("pipe");
		exit(EXIT_FAILURE);
	}
 
	pid = fork();
	if (pid == -1)
	{
		perror("fork");
		exit(EXIT_FAILURE);
	}
 
	if (pid == 0)
	{
		args[0] = "ls";
		args[1] = NULL;
		close(fd[0]); // close the read end of the pipe
		write(fd[1], "Hello parent!", 13);
		execve("/bin/ls", args, NULL);
		close(fd[1]); // close the write end of the pipe
		exit(EXIT_SUCCESS);
	}
	else
	{
		close(fd[1]); // close the write end of the pipe
		read(fd[0], buffer, 13);
		close(fd[0]); // close the read end of the pipe
		printf("Message from child: '%s'\n", buffer);
		exit(EXIT_SUCCESS);
	}
}*/

/*int main() //ls | wc
{
	int fd[2];
	pid_t pid;
    char *args[3];
	
    if (pipe(fd) == -1)
	{
		printf("pipe creation error");
		return(0);
	}
	pid = fork();
	if (pid == 0)
	{
		dup2(fd[1], 1);
        args[0] = "ls";
		args[1] = NULL;
		close(fd[0]); // close the read end of the pipe
		close(fd[1]);
        execve("/bin/ls", args, NULL);
		exit(1);
	}
	else
	{
		close(fd[1]); // close the write end of the pipe
        args[0] = "wc";
		args[1] = NULL;
        dup2(fd[0], STDIN_FILENO);
		close(fd[0]);
		execve("/usr/bin/wc", args, NULL);
		exit(1);
	}
}*/

/*int main() //dup
{
	int fd;
	int temp;
	fd = open("test", O_RDWR);
	temp = dup(STDOUT_FILENO);
	printf("fd%d\n", fd);
	printf("bfr dup\n");
    dup2(fd, 1);
	printf("Hello test file\n");
    dup2(temp, 1);
	printf("back in terminal\n");
}*/

/*int main(int argc, char **argv) //grandchildren
{
    pid_t pid,parent,a,b;

    parent = getpid();
    fork();
    a = getpid();
    if( a==parent )
    {
        printf("I am the parent: %d  %d\n",a, parent);
    }
    else
    {
        fork();
        b = getpid();
        if( a==b )
            printf("I am the child: %d %d %d\n",a, b, parent);
        else
            printf("I am the grandchild: %d %d\n", b, parent);
    }
    return(0);
}*/


/*int main(int argc, char **argv) // Simple MAIN
{
	int fd[2];
	int fex[2];
	pid_t pid1, pid2;
	char **args;
	int filein;
	int fileout;
	int temp;

	temp = dup(STDOUT_FILENO);
	checks(argc, argv);
	pipe(fd);
	pid1 = fork();
	filein = open(argv[1], O_RDONLY);
	fileout = open(argv[argc - 1], O_WRONLY);
	if (pid1 == 0)
	{
		args = ft_split(argv[2],' ');
		pipe(fex);
		pid2 = fork();
		if (pid2 == 0)
			extract_location(fex, args[0]),
		wait(NULL);
		close(fex[1]);
		close(fd[0]);
		dup2(filein, STDIN_FILENO);
		dup2(fd[1], STDOUT_FILENO);
		execve(get_next_line(fex[0]), args, NULL);
		dup2(temp, 1);
		write(1, "command not found\n", 18);
		exit(1);
	}
	args = ft_split(argv[3],' ');
	pipe(fex);
	pid2 = fork();
	if (pid2 == 0)
		extract_location(fex, args[0]);
	wait(NULL);
	close(fex[1]);
	close(fd[1]);
	dup2(fd[0], STDIN_FILENO);
	dup2(fileout, STDOUT_FILENO);
	close(fd[0]);
	execve(get_next_line(fex[0]), args, NULL);
	dup2(temp, 1);
	write(1, "command not found\n", 18);
	exit(1);
}*/


/*int main(int argc, char **argv)
{
	char *arg[3];

	(void)argc;
	arg[0] = "whereis";
	arg[1] = argv[1];
	arg[2] = NULL;

	printf("arg: <%s, %s, %s> <%p, %p, %p>\n", arg[0], arg[1], arg[2], arg[0], arg[1], arg[2]);
	printf("before exec\n");
	execve("/usr/bin/whereis", arg, NULL);
	printf("exec fail\n");
}*/

int main()
{
	if (access("test1", X_OK) != -1)
		printf("exec ok\n");
	else
		printf("exec Nok\n");
	if (access("test1", R_OK) != -1)
		printf("read ok\n");
	else
		printf("read Nok\n");
	if (access("test1", W_OK) != -1)
		printf("write ok\n");
	else
		printf("write Nok\n");
}

/*int main(int argc, char **argv)
{
	(void)argc;
	int fd = open(argv[1], O_RDWR);
	char *args[2];
	args[0] = "wc";
	args[1] = NULL;
	dup2(fd, STDIN_FILENO);
	execve("/usr/bin/wc", args, NULL);
}*/