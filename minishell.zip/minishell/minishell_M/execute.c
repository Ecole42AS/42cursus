/* Recieves a series of blocks composed of the labled text between pipes. (file_in cmd arg file_out)
Executes a block
Pipes the result if needed
Start again until finished 

There can be multiple infiles and outfiles
Only use LAST infile, (pipe is the 1st)
Write in LAST outfile (execpt pipe), but create all necessary new files
*/

//finds the comand location in the computer

#include "minishell.h"

char *append_str(char *str1, char *str2)
{
    char *ret;
    int i;
    int j;

    i = 0;
    ret = calloc(strlen(str1) + strlen(str2) + 1, sizeof(char));
    while (str1[i])
    {
        ret[i] = str1[i];
        i++;
    }
    j = i;
    i = 0;
    while(str2[i])
    {
        ret[i + j] = str2[i];
        i++;
    }
    return (ret);
}

//exacts the location of a given builtin command
void	extract_cmd_location(int fd[2], char *name)
{
	char	*arg[3];
	int		temp;

	arg[0] = "whereis";
	arg[1] = name;
	arg[2] = NULL;
	temp = dup(STDIN_FILENO);
	close(fd[0]);
	dup2(fd[1], STDOUT_FILENO);
	execve("/usr/bin/whereis", arg, NULL);
	write(temp, "extract location fail: ", 23);
	write(temp, name, strlen(name));
	write(temp, "\n", 1);
	exit(1);
}

//exacts the name of the file from the given location
char	*extract_prg_name(char *location)
{
    char *name;
    int i;

    name = location;
    i = 0;
    while (location[i])
    {
        if (location[i] == '/')
            name = location + i + 1;
        i++;
    }
    return (name);
}


void execute(int infile, char *location, char *name, char *arg, int outfile)
{
    char **args;
	(void) infile;
	(void) outfile;
    if (arg[0])
        arg = append_str(" ", arg);
    arg = append_str(name, arg);
    args = ft_split(arg, ' ');
	execve(location, args, NULL);
	exit(1);
}
