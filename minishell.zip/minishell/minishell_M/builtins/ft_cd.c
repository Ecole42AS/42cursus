#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

int main(int argc, char **argv)
{
    char *new_dir;
    char s[200];

    //might need to check for ~/ once the prompt is made
    if(chdir(argv[1]) != 0)
    {
           printf("minishell: cd: %s: No such file or directory\n", argv[1]);
           return (0);
    }
}