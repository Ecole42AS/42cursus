#include <string.h>
#include <stdio.h>
#include <unistd.h>

int main(int argc, char **argv)
{
    if (argc == 1)
    {
        write(1, "\n", 1);
        return(0);
    }
    if (argc = 3)
    {
        if (!strcmp(argv[1], "-n"))
            write(1, argv[2], strlen(argv[2]));
    }
    else
    {
        write(1, argv[1], strlen(argv[1]));
        write(1, "\n", 1);
    }
    return(0);
}