#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("declare -x COLORFGBG=\"%s\"\n", getenv("COLORFGBG"));
    printf("declare -x COLORTERM=\"%s\"\n", getenv("COLORTERM"));
    printf("declare -x COMMAND_MODE=\"%s\"\n", getenv("COMMAND_MODE"));
    printf("declare -x HOME=\"%s\"\n", getenv("HOME"));
    printf("declare -x ITERM_PROFILE=\"%s\"\n", getenv("ITERM_PROFILE"));
    printf("declare -x ITERM_SESSION_ID=\"%s\"\n", getenv("ITERM_SESSION_ID"));
    printf("declare -x LANG=\"%s\"\n", getenv("LANG"));
    printf("declare -x LC_TERMINAL=\"%s\"\n", getenv("LC_TERMINAL"));
    printf("declare -x LC_TERMINAL_VERSION=\"%s\"\n", getenv("LC_TERMINAL_VERSION"));
    printf("declare -x LOGNAME=\"%s\"\n", getenv("LOGNAME"));
    printf("declare -x LaunchInstanceID=\"%s\"\n", getenv("LaunchInstanceID"));
    printf("declare -x OLDPWD=\"%s\"\n", getenv("OLDPWD"));
    printf("declare -x PATH=\"%s\"\n", getenv("PATH"));
    printf("declare -x PWD=\"%s\"\n", getenv("PWD"));
    printf("declare -x SECURITYSESSIONID=\"%s\"\n", getenv("SECURITYSESSIONID"));
    printf("declare -x SHELL=\"%s\"\n", getenv("SHELL"));
    printf("declare -x SHLVL=\"%s\"\n", getenv("SHLVL"));
    printf("declare -x SSH_AUTH_SOCK=\"%s\"\n", getenv("SSH_AUTH_SOCK"));
    printf("declare -x TERM=\"%s\"\n", getenv("TERM"));
    printf("declare -x TERM_PROGRAM=\"%s\"\n", getenv("TERM_PROGRAM"));
    printf("declare -x TERM_PROGRAM_VERSION=\"%s\"\n", getenv("TERM_PROGRAM_VERSION"));
    printf("declare -x TERM_SESSION_ID=\"%s\"\n", getenv("TERM_SESSION_ID"));
    printf("declare -x TMPDIR=\"%s\"\n", getenv("TMPDIR"));
    printf("declare -x USER=\"%s\"\n", getenv("USER"));
    printf("declare -x XPC_FLAGS=\"%s\"\n", getenv("XPC_FLAGS"));
    printf("declare -x XPC_SERVICE_NAME=\"%s\"\n", getenv("XPC_SERVICE_NAME"));
    printf("declare -x __CF_USER_TEXT_ENCODING=\"%s\"\n", getenv("__CF_USER_TEXT_ENCODING"));
}



int main(int argc, char **argv)
{
    if (argc == 1)
    {

        printf("declare -x %s==\"%s\"\n", log[i], getenv(log[i]))
    }
}