#include <stdlib.h>
#include <stdio.h>

int main()
{
    char s[50];
    
    printf("cwd: %s\n",getcwd(s, 50));
}