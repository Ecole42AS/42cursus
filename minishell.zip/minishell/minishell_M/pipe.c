/*
Number of pipes is neccessarz (cf gen)
*/
#include "minishell.h"

// runs the exectuer for every pipe


void comander(char *name, char *location, t_pars *block)
{
    if (block->type == 'C')
    {
        name = extract_prg_name(block->cmd);
	    pipe(fd);
    	pid = fork();
	    if (pid == 0)
	        extract_cmd_location(fd, name);
        close(fd[1]);
        location = get_next_line(fd[0]);
    }
    if (block->type == 'P')
    {
       location = block->cmd;
       name = extract_prg_name(location);
       break;
    }
    if (block->type == 'B')
    {

    }
}

void pipes(struct *block)
{
    char *name;
    char *location;
    while (1)
    {
        comander(name, location, block)
        execute(block.infile, location, name, block.args, block.outfile)
        if (block->next == NULL)
            break;
    }
}


void deconstruct(char **arguments, char**values)
{
    char *location;
    char *name;
    char *args;
    int fd[2];
    pid_t pid;
    int infile;
    int outfile;
    int i;


    i = 0;
    infile = STDIN_FILENO;
    outfile = STDOUT_FILENO;

    while (values[i])
    {
        if (values[i][0] == 'C')
        {
            name = extract_prg_name(arguments[i]);
	        pipe(fd);
    	    pid = fork();
	        if (pid == 0)
	        	extract_cmd_location(fd, name);
            close(fd[1]);
            location = get_next_line(fd[0]);
            break;
        }
        if (values[i][0] == 'P')
        {
            location = arguments[i];
            name = extract_prg_name(location);
            break;
        }
        i++;
    }
    i = 0;
    args = malloc(1 * sizeof(char));
    args[0] = 0;
    while (values[i])
    {
        if (values[i][0] == 'A')
            args = arguments[i];
        if (values[i][0] == 'i' || values[i][0] == 'I')
            infile = atoi(arguments[i]);
        if (values[i][0] == 'o' || values[i][0] == 'O')
            outfile = atoi(arguments[i]);
        i++;
    }
    execute(infile, location, name, args, outfile) ;
}

int main()
{
    char *arguments[3] = {"echo", "~ @ \\", 0};
    char *values[3] = {"C", "A", 0};
    deconstruct(arguments, values);
}