
#ifndef MINISHELL_H
# define MINISHELL_H 

# include <stdio.h>
# include <unistd.h>
# include <stdlib.h>
# include <fcntl.h>
# include <string.h>
# include <math.h>

void deconstruct(char **arguments, char**values);
char    *append_str(char *str1, char *str2);
void    extract_cmd_location(int fd[2], char *name);
char    *extract_prg_name(char *location);
void    execute(int infile, char *location, char *name, char *arg, int outfile);
char	*get_next_line(int fd);
char	**ft_split(char *str, char charset);

#endif