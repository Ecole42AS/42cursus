/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strndup.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: astutz <astutz@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/02 16:08:05 by astutz            #+#    #+#             */
/*   Updated: 2023/09/02 16:17:05 by astutz           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char *ft_strndup(const char *s, int len)
{
    char *ptr;

    if (len < 0)
        len = ft_strlen(s);
    
    ptr = (char *)malloc((len + 1) * sizeof(char));
    if (!ptr)
        return (NULL);
    
    ft_memmove(ptr, s, len);
    ptr[len] = '\0';
    
    return (ptr);
}

// int main() {
//     const char *original = "Bonjour, le monde!";
//     size_t len = -1; // Nombre de caractères à dupliquer

//     // Utilisation de ft_strndup
//     char *ft_duplicate = ft_strndup(original, len);
//     if (ft_duplicate) {
//         printf("Chaîne originale : %s\n", original);
//         printf("Chaîne dupliquée avec ft_strndup : %s\n", ft_duplicate);
//         free(ft_duplicate);
//     } else {
//         perror("Erreur lors de la duplication avec ft_strndup");
//     }

//     // Utilisation de strndup (fonction de la bibliothèque standard)
//     char *std_duplicate = strndup(original, len);
//     if (std_duplicate) {
//         printf("Chaîne originale : %s\n", original);
//         printf("Chaîne dupliquée avec strndup : %s\n", std_duplicate);
//         free(std_duplicate);
//     } else {
//         perror("Erreur lors de la duplication avec strndup");
//     }

//     return 0;
// }
