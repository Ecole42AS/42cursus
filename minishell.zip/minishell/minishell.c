/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minishell.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: astutz <astutz@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/02 09:38:06 by astutz            #+#    #+#             */
/*   Updated: 2023/09/02 10:49:12 by astutz           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

int	g_exit_code = 0;

int	main(int ac, char **av, char **env)
{
	env_var_list	*envi;
	char			*input;
	command_line 	*line;


	(void)ac;
	(void)av;
	line = malloc(sizeof(command_line));
	envi = malloc(sizeof(env_var_list));
	ft_memset(envi, 0, sizeof(env_var_list));
	init_termios();
	input = "start";
	while (input != NULL)
	{
		input = readline("Minishell >");
		if (((input && input[0] == '\0') || input == NULL) || ft_is_only_space(input) == 0)
			continue ;
		lexer(input, envi, &line);
		free(input);
	}
	ft_putstr_fd("exit\n", STDOUT_FILENO);
	free(input);
	return (g_exit_code);
}