#include <stdio.h>
#include <stdlib.h>

extern char **environ; // Déclaration de la variable environ

int main() {
    // Parcourir le tableau environ et afficher les variables d'environnement
    for (int i = 0; environ[i] != NULL; i++) {
        printf("%s\n", environ[i]);
    }

    return 0;
}
